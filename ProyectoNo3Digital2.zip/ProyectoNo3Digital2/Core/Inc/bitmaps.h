/*
 * bitmaps.h
 *
 *  Created on: Saber Pa
 *      Author: Alex
 */

#ifndef INC_BITMAPS_H_
#define INC_BITMAPS_H_

unsigned char Parqueo []=
{
	//Hola
};


/*********************************************************************************************************
  END FILE
*********************************************************************************************************/
#endif /* INC_BITMAPS_H_ */
