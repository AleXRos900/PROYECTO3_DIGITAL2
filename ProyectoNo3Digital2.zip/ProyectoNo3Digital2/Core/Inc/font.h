#ifndef INC_FONT_H_
#define INC_FONT_H_

#include <stdint.h>

#define fontXSizeSmal 8
#define fontYSizeSmal 12
#define fontXSizeBig 16
#define fontYSizeBig 16
#define fontXSizeNum 32
#define fontYSizeNum 50

#define fontdatatype const uint8_t
#define fontdatatype16 const uint16_t



#endif
